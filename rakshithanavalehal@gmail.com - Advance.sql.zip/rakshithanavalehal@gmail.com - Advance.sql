--SQL Advance Case Study


--Q1--BEGIN 


select distinct l.state
 from [fact_transactions] f inner join [dim_location] l on f.Idlocation = l.Idlocation
 where f.date between '2005-01-01' and GETDATE()
	

--Q1--END

--Q2--BEGIN


select top 1 state, sum(f.totalprice)[Total_Price] 
    from dim_manufacturer b inner join dim_model m on b.idmanufacturer = m.idmanufacturer
						    inner join fact_transactions f on f.idmodel = m.idmodel
						    inner join dim_location l on l.idlocation = f.idlocation
  where b.manufacturer_name = 'Samsung' and l.Country = 'US'
  group by l.state
  order by [Total_Price] desc



--Q2--END

--Q3--BEGIN 


select f.idmodel, l.zipcode, l.State, count(f.idcustomer)[No_of_transaction] 
 from fact_transactions f inner join dim_location l on f.idlocation = l.idlocation
 group by f.idmodel, l.zipcode, l.State

	

--Q3--END

--Q4--BEGIN


select top 1 model_name, 
 unit_price from dim_model 
 order by unit_price asc



--Q4--END

--Q5--BEGIN


select top 5 b.Manufacturer_Name, m.Model_name, sum(f.quantity)[Total_Qty], avg(f.totalprice)[Total_Price] from 
	             fact_transactions f inner join dim_model m on f.idmodel = m.idmodel
						             inner join dim_manufacturer b on b.idmanufacturer = m.idmanufacturer
 group by b.Manufacturer_Name, m.Model_name
 order by avg(f.totalprice) desc




--Q5--END

--Q6--BEGIN


select c.Customer_Name, avg(f.totalPrice)[Avg_Amt_Spent] 
  from dim_customer c inner join fact_transactions f on c.idcustomer = f.idcustomer
  where f.Date between '2009-01-01' and '2009-12-31' 
  group by c.Customer_Name 
  having avg(f.totalPrice) > 500
  order by [Avg_Amt_Spent] desc



--Q6--END
	
--Q7--BEGIN  


select Idmodel,sum(Quantity)[Total_Qty]from fact_transactions
 where Date between '2008-01-01' and '2010-12-31'
 group by Idmodel
 having idmodel in (select idmodel from 
(select top 5 Idmodel,sum(Quantity)[Total_Qty]from fact_transactions
 where Date between '2008-01-01' and '2008-12-31'
 group by Idmodel
 order by Total_Qty desc
) as A
 intersect
 select idmodel from 
(select top 5 Idmodel,sum(Quantity)[Total_Qty]from fact_transactions
 where Date between '2009-01-01' and '2009-12-31'
 group by Idmodel
 order by Total_Qty desc
) as B
 intersect
 select idmodel from 
(select top 5 Idmodel,sum(Quantity)[Total_Qty]from fact_transactions
 where Date between '2010-01-01' and '2010-12-31'
 group by Idmodel
 order by Total_Qty desc
) as C )
;

	
	

--Q7--END

--Q8--BEGIN


select Manufacturer_name, Top_Sales from (select b.manufacturer_name, sum (f.Totalprice) [Top_Sales]from 
	             fact_transactions f inner join dim_model m on f.idmodel = m.idmodel
						             inner join dim_manufacturer b on b.idmanufacturer = m.idmanufacturer
 where f.Date between '2009-01-01' and '2009-12-31'
 group by b.manufacturer_name
 order by Top_Sales desc
 offset 1 row
 fetch next 1 row only
) t1
union
select Manufacturer_name, Top_Sales from (select b.manufacturer_name, sum (f.Totalprice) [Top_Sales]from 
	             fact_transactions f inner join dim_model m on f.idmodel = m.idmodel
						             inner join dim_manufacturer b on b.idmanufacturer = m.idmanufacturer
 where f.Date between '2010-01-01' and '2010-12-31'
 group by b.manufacturer_name
 order by Top_Sales desc
 offset 1 row
 fetch next 1 row only
) t2




--Q8--END

--Q9--BEGIN


select b.Manufacturer_Name from 
	           fact_transactions f inner join dim_model m on f.idmodel = m.idmodel
						           inner join dim_manufacturer b on b.idmanufacturer = m.idmanufacturer
 where f.Date between '2010-01-01' and '2010-12-31'

except

select b.Manufacturer_Name from 
	          fact_transactions f inner join dim_model m on f.idmodel = m.idmodel
						          inner join dim_manufacturer b on b.idmanufacturer = m.idmanufacturer
 where f.Date between '2009-01-01' and '2009-12-31'



--Q9--END

--Q10--BEGIN


with top_customers as 
	 ( select YEAR(Date) [Transaction_year], idcustomer, AVG(totalprice)[Avg_Spend], AVG(Quantity)[Avg_Qty],
	 row_number () over (Partition by Year(Date) order by sum(Totalprice) desc)[Customer_rank]
	 from FACT_TRANSACTIONS
     where YEAR(date) between 2003 and 2010
     group by year(date), IDCustomer ),
 
Customer_Spend as 
	 ( select idcustomer, Transaction_year, Avg_Spend, 
	 lag(Avg_Spend, 1) over (Partition by idcustomer order by Transaction_year) as Prev_Spend
     from top_customers
     where Customer_rank <= 100 )
 
select
	cs.IDCustomer,
	cs.Transaction_Year,
	cs.Avg_Spend,
	cs.Prev_Spend,
	((cs.Avg_Spend - cs.Prev_Spend)/cs.Prev_Spend) * 100 [Spend_Percentage_Change]
    from Customer_Spend cs
    where cs.Transaction_year > 2003
    order by cs.Transaction_year, 
	cs.IDCustomer;
	

--Q10--END
	